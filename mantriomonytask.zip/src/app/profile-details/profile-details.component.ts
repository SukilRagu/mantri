
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductsService } from '../product.service';
@Component({
  selector: 'app-profile-details',
  templateUrl: './profile-details.component.html',
  styleUrls: ['./profile-details.component.css']
})
export class ProfileDetailsComponent implements OnInit {
  [x: string]: any;
  id: number | undefined;
  private sub: any; 
  products:any[]=[];
  selectedData:any;


  constructor(private route: ActivatedRoute,
              private _router:Router,
              private productService:ProductsService) {}
  ngOnInit() {
  
   this.productService.getProduct().subscribe(res=>{
     this.products=res;
     this.sub = this.route.params.subscribe(params => {
      this.id = +params['id']; // (+) converts string 'id' to a number
      this.selectedData=this.products.filter(item=>item.id==this.id);
      
      this.product=this.selectedData;
      console.log(this.product);
   })
   // In a real app: dispatch action to load the details here.
    });

  // Find the product that correspond with the id provided in route.
 // this.product = products.find(product => product.id === productIdFromRoute);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}