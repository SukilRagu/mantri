export interface products {
    id: Number;
    product_title: String;
    product_price: Number;
    product_description: String;
    created_at: String;
    product_image: any;
}
